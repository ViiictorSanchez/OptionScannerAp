@extends('layouts.master')

@section('breadcrumb')
                            <h4 class="page-title">Directory</h4>
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javascript:void(0);">Lexa</a></li>
                                <li class="breadcrumb-item"><a href="javascript:void(0);">Pages</a></li>
                                <li class="breadcrumb-item active">Directory</li>
                            </ol>
@endsection

@section('content')
        <div class="wrapper">
            <div class="container-fluid">
                  
            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->
@endsection